<?php
    function __autoload($imeKlase) {
        if (preg_match('/^([A-Z][a-z]+)+Controller$/', $imeKlase)) {
            require_once 'controllers/' . $imeKlase . '.php';
        } else if (preg_match('/^([A-Z][a-z]+)+Model$/', $imeKlase)) {
            require_once 'models/' . $imeKlase . '.php';
        } else if (in_array($imeKlase, ['DataBase'])) {
            require_once 'sys/' . $imeKlase . '.php';
        }
    }
