<?php
class StudentModel {
    public static function getAll() {
        $SQL = 'SELECT * FROM student';
        $prep = DataBase::getInstance()->prepare($SQL);
        $prep->execute();
        return $prep->fetchAll(PDO::FETCH_OBJ);
    }

    public static function getById($id) {
        $SQL = 'SELECT * FROM student WHERE id=?';
        $prep = DataBase::getInstance()->prepare($SQL);
        $prep->execute([$id]);
        return $prep->fetch(PDO::FETCH_OBJ);
    }

    public static function edit($id, $name) {
        $SQL = 'UPDATE student SET `name` = ? WHERE id = ?';
        $prep = DataBase::getInstance()->prepare($SQL);
        
        if (!$prep) {
            return false;
        }
        
        return $prep->execute([$name, $id]);
    }
}
