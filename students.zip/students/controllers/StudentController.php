<?php
    class StudentController {
        public function getAll() {
            return CategoryModel::getAll();
        }
        
        public function getById($id) {
            return CategoryModel::getById($id);
        }
        
        public function edit($id) {
            # promeniti vrednosti zapisa pod ID-em $id
            # sta da stavimo za nove vrednosti tog zapisa? ne znamo jos
            # ko nam dostavlja vrednosti? korisnik
            # kako od korisnika uzeti vrednosti? poslace nam kroz http post
            # kako uzimamo podatke iz http post i u kom formatu dolaze? format=json, kako=nauci
            $postdata = file_get_contents("php://input");
            # kako da konvertujemo podatke iz json stringa u objekat u php-u? nauciti
            $podaci = json_decode( $postdata );
            # proveriti da li su podaci ispravan objekat i da li u tom objektu postoje zeljena polja
            
            if (!property_exists($podaci, 'name')) {
                return [
                    "status" => "error",
                    "data" => "Ne postoji name polje u podacima."
                ];
            }
            
            if (!preg_match('|^[A-Z][A-z0-9 ]*$|', $podaci->name)) {
                return [
                    "status" => "error",
                    "data" => "Vrednsot name nije dobra."
                ];
            }
            
            $rezultat = CategoryModel::edit($id, $podaci->name);

            if (!$rezultat) {
                return [
                    "status" => "error",
                    "data" => "Doslo je do greske."
                ];
            }
            
            return [
                "status" => "ok",
                "data" => "Izmenili smo ime kategorije."
            ];
        }
    }
